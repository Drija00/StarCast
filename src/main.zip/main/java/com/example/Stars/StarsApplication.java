package com.example.Stars;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StarsApplication {

	public static void main(String[] args) {
		SpringApplication.run(StarsApplication.class, args);
	}

}
